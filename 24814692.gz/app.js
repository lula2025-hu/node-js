const os = require('os');
const https = require('https'); // Import the 'https' module for SSL
const { Buffer } = require('buffer');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const net = require('net');
const { exec, execSync } = require('child_process');
const { WebSocket, createWebSocketStream } = require('ws');
const logcb = (...args) => console.log.bind(this, ...args);
const errcb = (...args) => console.error.bind(this, ...args);
const UUID = process.env.UUID || '1d13bacd-db1c-45ce-9b05-9a44b7460535';
const uuid = UUID.replace(/-/g, "");
const DOMAIN = process.env.DOMAIN || 'node62.lunes.host';  //项目域名或已反代的域名，不带前缀，建议填已反代的域名
const NAME = process.env.NAME || 'Lunes-Host';
const port = process.env.PORT || 3096;

// --- SSL Configuration ---
// Note: You must provide your own SSL certificate and private key files.
// Place 'cert.pem' and 'key.pem' in the same directory as this script.
const sslOptions = {
  key: fs.readFileSync(path.join(__dirname, 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
};

// Create HTTPS server instead of HTTP
const httpsServer = https.createServer(sslOptions, (req, res) => {
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Unauthorized access, please start through the game page (over HTTPS)\n');
    } else if (req.url === '/1HLzZI6Z4nVsj8So') {
        // The VLESS URL should now point to port 443 for standard HTTPS
        const vlessURL = `vless://${UUID}@${DOMAIN}:443?encryption=none&security=tls&sni=${DOMAIN}&type=ws&host=${DOMAIN}&path=%2F#${NAME}`;

        const base64Content = Buffer.from(vlessURL).toString('base64');

        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(base64Content + '\n');
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Unauthorized access, please start through the game page (over HTTPS)\n');
    }
});

httpsServer.listen(port, () => {
    // Note: The server is now running on HTTPS.
    // If you are using a standard port like 443, you might need to run with sudo.
    console.log(`HTTPS Server is running on port ${port}`);
});

// Attach WebSocket server to the HTTPS server
const wss = new WebSocket.Server({ server: httpsServer });
wss.on('connection', ws => {
    ws.on('message', msg => {
        if (msg.length < 18) {
            return;
        }
        try {
            const [VERSION] = msg;
            const id = msg.slice(1, 17);
            if (!id.every((v, i) => v == parseInt(uuid.substr(i * 2, 2), 16))) {
                return;
            }
            let i = msg.slice(17, 18).readUInt8() + 19;
            const port = msg.slice(i, i += 2).readUInt16BE(0);
            const ATYP = msg.slice(i, i += 1).readUInt8();
            const host = ATYP === 1 ? msg.slice(i, i += 4).join('.') :
                (ATYP === 2 ? new TextDecoder().decode(msg.slice(i + 1, i += 1 + msg.slice(i, i + 1).readUInt8())) :
                    (ATYP === 3 ? msg.slice(i, i += 16).reduce((s, b, i, a) => (i % 2 ? s.concat(a.slice(i - 1, i + 1)) : s), []).map(b => b.readUInt16BE(0).toString(16)).join(':') : ''));
            ws.send(new Uint8Array([VERSION, 0]));
            const duplex = createWebSocketStream(ws);
            net.connect({ host, port }, function () {
                this.write(msg.slice(i));
                duplex.on('error', err => console.error("E1:", err.message)).pipe(this).on('error', err => console.error("E2:", err.message)).pipe(duplex);
            }).on('error', err => console.error("Connection error:", err.message));
        } catch (err) {
            console.error("Error processing message:", err.message);
        }
    }).on('error', err => console.error("WebSocket error:", err.message));
});
